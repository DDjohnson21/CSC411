use csc411_image::{Read, Rgb, RgbImage};
use array2::Array2;
use crate::rgb_float_conversion::rgb_to_float;
use crate::rgb_float_ypbpr_conversion::float_to_ypbpr;
use crate::process::process_blocks;
use std::io::{self};

// compress function that takes in an optional filename and returns a Result
// The function reads in an image file, trims the image to an even size, converts the RGB values to YPbPr values, and then compresses the image using the RPEG algorithm.
pub fn compress(filename: Option<&str>) -> io::Result<()> {
    // Trim array
    let trimmed_array = prepare_array(filename);
    // Convert to RGB floats
    let rgb_float_array = rgb_to_float(&trimmed_array);
    // Convert to YPbPr values
    let ypbpr_array = float_to_ypbpr(&rgb_float_array);
    // Convert array to block major order
    let block_major_array = ypbpr_array.to_2x2_block_major();

    // Process blocks and output results
    process_blocks(block_major_array); 
    
    Ok(())
}

// prepare_array function trims array to even size
// The function reads in an image file and trims the image to an even size
fn prepare_array(filename: Option<&str>)->Array2<Rgb> {
    let img = RgbImage::read(filename.as_deref()).unwrap(); // Read the image
    let array = Array2::from_row_major(img.width as usize, img.height as usize, img.pixels).expect("Vector size does not match the specified dimensions.");
    let trimmed_image = array.trim_to_even();
    return trimmed_image;
}


// decompress function that takes in an optional filename and returns a Result
pub fn decompress(filename: Option<&str>) -> io::Result<()> {
    // 
    prepare_array(filename);

    Ok(())
}