use csc411_image::{Read, Rgb, RgbImage};
use array2::Array2;
use bitpack::bitpack;

use std::io::{self, Write};

pub fn compress(filename: Option<&str>) -> io::Result<()> {
    let trimmed_image = prepareArray(filename);

    let ypbpr_array = convert_rgb_to_ypbpr(trimmed_image);

    let block_major_array = ypbpr_array.to_2x2_block_major();

    // Call process_blocks
    let codewords = process_blocks(block_major_array);

    // Use codewords for whatever you need next
    for codeword in codewords {
        println!("{:?}", codeword.unwrap());
    }

    // println!("{:?}", getu(0x3f4, 6, 2));
        
    // // Use new array to create a new image
    // let image = RgbImage {            
    //     pixels: codewords.data(),
    //     width: codewords.width() as u32,bitpack::getu(0x3f4, 6, 2) == Some(61)
    //     height: codewords.height() as u32,
    //     denominator: 255,
    // };


    // // Print the image to stdout
    // let _image_output = image.write(None);

    // convere to grey scale
    

    Ok(())
}


pub fn decompress(filename: Option<&str>) -> io::Result<()> {
    prepareArray(filename);

    Ok(())
}

fn prepareArray(filename: Option<&str>)->Array2<Rgb> {
    let img = RgbImage::read(filename.as_deref()).unwrap(); // Read the image
    let width = img.width as usize;
    let height = img.height as usize;
    let array = Array2::from_row_major(width, height, img.pixels).expect("Vector size does not match the specified dimensions.");
    let trimmed_image = array.trim_to_even();
    return trimmed_image;
}

fn convert_rgb_to_ypbpr(rgb_array: Array2<Rgb>) -> Array2<(f32, f32, f32)> {
    // Convert each RGB tuple from u8 to f32
    let converted: Vec<(f32, f32, f32)> = rgb_array.data().iter().map(|&Rgb { red: r, green: g, blue: b }| {
        // Now you can use r, g, b here
        let r_f32 = r as f32 / 255.0;
        let g_f32 = g as f32 / 255.0;
        let b_f32 = b as f32 / 255.0;

        // Calculate YPbPr components
        let y = 0.299 * r_f32 + 0.587 * g_f32 + 0.114 * b_f32;
        let pb = -0.168736 * r_f32 - 0.331264 * g_f32 + 0.5 * b_f32;
        let pr = 0.5 * r_f32 - 0.418688 * g_f32 - 0.081312 * b_f32;

        (y, pb, pr)
    }).collect();

    Array2::from_row_major(rgb_array.width(), rgb_array.height(), converted).unwrap()
}

// Reverse of the above function (Part 3)
// NEEDS WORK
// DECOMPRESSION
// pub fn ypbpr_to_rgb(y: f32, pb: f32, pr: f32) -> (u8, u8, u8) {
    
//     let r = y + 1.402 * pr;
//     let g = y - 0.344136 * pb - 0.714136 * pr;
//     let b = y + 1.772 * pb;

//     return (r as u8, g as u8, b as u8)
// }


pub fn pack_values(y_values: [i64; 4], pb_average: f32, pr_average: f32) -> Option<u64> {
    let mut word: u64 = 0;
    
    let y1 = y_values[0];
    let y2 = y_values[1];
    let y3 = y_values[2];
    let y4 = y_values[3];


    // Calculate the average of the Y values
    let a = (y4 + y3 + y2 + y1) / 4;
    let b = (y4 + y3 - y2 - y1) / 4;
    let c = (y4 - y3 + y2 - y1) / 4;
    let d = (y4 - y3 - y2 + y1) / 4;
    let index_pb = csc411_arith::index_of_chroma(pb_average) as u64;
    let index_pr = csc411_arith::index_of_chroma(pr_average) as u64;


    // quantized values
    word = bitpack::newu(word, 4, 0, index_pr)?;
    word = bitpack::newu(word, 4, 4, index_pb)?;
    word = bitpack::news(word, 5, 8, d)?;
    word = bitpack::news(word, 5, 13, c)?;
    word = bitpack::news(word, 5, 18, b)?;
    word = bitpack::newu(word, 9, 23, a as u64)?;

    // word = newu(word, 4, 0, index_pr)?;
    // word = newu(word, 4, 4, index_pb)?;
    // word = news(word, 5, 8, d)?;
    // word = news(word, 5, 13, c)?;
    // word = news(word, 5, 18, b)?;
    // word = newu(word, 9, 23, a as u64)?;

    Some(word)
}
//-> Array2<Option<u64>>
fn process_blocks(array: Array2<(f32, f32, f32)>) -> Vec<Option<u64>>{
    let mut codewords = Vec::new();
    let blocks_across = array.width() / 2;
    let blocks_down = array.height() / 2;

    for block_row in 0..blocks_down {
        for block_col in 0..blocks_across {
            let mut y_values = [0i64; 4];
            let mut pb_values = vec![];
            let mut pr_values = vec![];

            for row_offset in 0..2 {
                for col_offset in 0..2 {
                    let index = (block_row * 2 + row_offset) * array.width() + (block_col * 2 + col_offset);
                    if let Some(pixel) = array.data().get(index) {
                        y_values[row_offset * 2 + col_offset] = pixel.0 as i64;
                        pb_values.push(pixel.1);
                        pr_values.push(pixel.2);
                    }
                }
            }

            let pb_average: f32 = pb_values.iter().sum::<f32>() / pb_values.len() as f32;
            let pr_average: f32 = pr_values.iter().sum::<f32>() / pr_values.len() as f32;
            
            if let Some(codeword) = pack_values(y_values, pb_average, pr_average) {
                codewords.push(Some(codeword));
            } else {
                codewords.push(None);
            }
        }
    }

    codewords
    // Array2::from_row_major(array.width() / 2, array.height() / 2, codewords).unwrap()
    
}


// To create new array, we add values to a new array and then constuct from Row major order



// COMPRESS

// Read in file
// Create array2 DONE
// Trim array DONE
// Chnage values fom RGB to YPbPr DONE
// Create a new array in 2x2 blocks NEEDS WORK
// Iterate iover the blocks and compress them into a single 32-bit word THINK IS DONE
// Add the word to a vector DONE
// Return the vector DONE

// DECOMPRESS
// TODO


///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
// 
//
// -------------------------------------------

// /// Returns true iff the signed value `n` fits into `width` signed bits.
// ///
// /// # Arguments:
// /// * `n`: A signed integer value
// /// * `width`: the width of a bit field
// pub fn fitss(n: i64, width: u64) -> bool {
//     if width == 0 { return false; } // Edge case: no space to fit any number
//     let max_positive: i64 = (1 << (width - 1)) - 1;
//     let min_negative: i64 = -1 << (width - 1);
//     n >= min_negative && n <= max_positive
// }

// /// Returns true iff the unsigned value `n` fits into `width` unsigned bits.
// ///
// /// # Arguments:
// /// * `n`: An unsigned integer value
// /// * `width`: the width of a bit field
// pub fn fitsu(n: u64, width: u64) -> bool {
//     width != 0 && n < (1u64 << width)
// }

// /// Retrieve a signed value from `word`, represented by `width` bits
// /// beginning at least-significant bit `lsb`.
// /// Returns `None` if `width+lsb>64` or `width` is 0.
// ///
// /// # Arguments:
// /// * `word`: An unsigned word
// /// * `width`: the width of a bit field
// /// * `lsb`: the least-significant bit of the bit field

// // pub fn gets(word: u64, width: u64, lsb: u64) -> Option<i64> {

// // }

// /// Retrieve an unsigned value from `word`, represented by `width` bits
// /// beginning at least-significant bit `lsb`.
// /// Returns `None` if `width+lsb>=64`
// ///
// /// # Arguments:
// /// * `word`: An unsigned word
// /// * `width`: the width of a bit field
// /// * `lsb`: the least-significant bit of the bit field

// // pub fn getu(word: u64, width: u64, lsb: u64) -> Option<u64> {


// // }

// /// Return a modified version of the unsigned `word`,
// /// which has been updated so that the `width` bits beginning at
// /// least-significant bit `lsb` now contain the unsigned `value`.
// /// Returns an `Option` which will be None iff the value does not fit
// /// in `width` unsigned bits.
// ///
// /// # Arguments:
// /// * `word`: An unsigned word
// /// * `width`: the width of a bit field
// /// * `lsb`: the least-significant bit of the bit field
// /// * `value`: the unsigned value to place into that bit field
// pub fn newu(word: u64, width: u64, lsb: u64, value: u64) -> Option<u64> {
//     if !fitsu(value, width) || lsb + width > 64 {
//         None
//     } else {
//         let mask = ((1 << width) - 1) << lsb;
//         Some((word & !mask) | ((value << lsb) & mask))
//     }
// }

// /// Return a modified version of the unsigned `word`,
// /// which has been updated so that the `width` bits beginning at
// /// least-significant bit `lsb` now contain the signed `value`.
// /// Returns an `Option` which will be None iff the value does not fit
// /// in `width` signed bits.
// ///
// /// # Arguments:
// /// * `word`: An unsigned word
// /// * `width`: the width of a bit field
// /// * `lsb`: the least-significant bit of the bit field
// /// * `value`: the signed value to place into that bit field
// pub fn news(word: u64, width: u64, lsb: u64, value: i64) -> Option<u64> {
//     if !fitss(value, width) || lsb + width > 64 {
//         None
//     } else {
//         let mask = ((1 << width) - 1) << lsb;
//         let value_masked = (value as u64) & ((1 << width) - 1);
//         Some((word & !mask) | ((value_masked << lsb) & mask))
//     }
// }