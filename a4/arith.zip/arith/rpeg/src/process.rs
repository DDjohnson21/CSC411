use array2::Array2;
use bitpack::bitpack;
use crate::ypbpr::YPbPr;

pub fn pack_values(y_values: [i64; 4], pb_average: f32, pr_average: f32) -> Option<u64> {
    let mut word: u64 = 0;
    
    // Access Y values
    let y1 = y_values[0];
    let y2 = y_values[1];
    let y3 = y_values[2];
    let y4 = y_values[3];

    // Calculate the average of the Y values
    let a = (y4 + y3 + y2 + y1) / 4;
    let b = (y4 + y3 - y2 - y1) / 4;
    let c = (y4 - y3 + y2 - y1) / 4;
    let d = (y4 - y3 - y2 + y1) / 4;
    let index_pb = csc411_arith::index_of_chroma(pb_average) as u64;
    let index_pr = csc411_arith::index_of_chroma(pr_average) as u64;

    // Quantized values
    word = bitpack::newu(word, 4, 0, index_pr)?;
    word = bitpack::newu(word, 4, 4, index_pb)?;
    word = bitpack::news(word, 5, 8, d)?;
    word = bitpack::news(word, 5, 13, c)?;
    word = bitpack::news(word, 5, 18, b)?;
    word = bitpack::newu(word, 9, 23, a as u64)?;

    Some(word)
}

// process_blocks function that takes in an Array2 of YPbPr values and returns an Array2 of 32-bit words.
pub fn process_blocks(array: Array2<YPbPr>){
    // Create a Vec to store the codewords
    let mut codewords:Vec<[u8;4]> = Vec::new();
    // Calculate the number of blocks across and down
    let blocks_across = array.width() / 2;
    let blocks_down = array.height() / 2;

    // Loop through the blocks
    for block_row in 0..blocks_down {
        for block_col in 0..blocks_across {
            // Initialize the values
            let mut y_values = [0i64; 4];
            let mut pb_values = vec![];
            let mut pr_values = vec![];
            // Loop through the pixels in the block
            for row_offset in 0..2 {
                for col_offset in 0..2 {
                    // Get the index of the pixel
                    let index = (block_row * 2 + row_offset) * array.width() + (block_col * 2 + col_offset);
                    // Get the pixel from the array
                    if let Some(pixel) = array.data().get(index) {
                        // Add the Y values to the y_values array
                        y_values[row_offset * 2 + col_offset] = pixel.y as i64;
                        pb_values.push(pixel.pb);
                        pr_values.push(pixel.pr);
                    }
                }
            }
            // Calculate the average of the Pb and Pr values
            let pb_average: f32 = pb_values.iter().sum::<f32>() / pb_values.len() as f32;
            let pr_average: f32 = pr_values.iter().sum::<f32>() / pr_values.len() as f32;
            
            // Pack the values into a codeword
            if let Some(codeword) = pack_values(y_values, pb_average, pr_average) {
                // Add the codeword to the codewords array
                codewords.push((codeword as u32).to_be_bytes());
            }
            else {
                // Add a zero codeword if the codeword is None
                codewords.push([0, 0, 0, 0]);
            }
        }
        // Output the codewords
        csc411_rpegio::output_rpeg_data(&codewords, array.width(), array.height()).unwrap();
    }
}