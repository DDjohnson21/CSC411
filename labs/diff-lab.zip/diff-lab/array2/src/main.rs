// TESTING

use array2::Array2;


fn convert_rgb_to_f32(rgb_array: Array2<(u8, u8, u8)>) -> Array2<(f32, f32, f32)> {
    // Convert each RGB tuple from u8 to f32
    let converted: Vec<(f32, f32, f32)> = rgb_array.data().iter().map(|&(r, g, b)| {
        // Convert each component to f32 in the range 0.0 to 1.0
        (
            r as f32 / 255.0,
            g as f32 / 255.0,
            b as f32 / 255.0,
        )
    }).collect();

    // Use from_row_major to create a new Array2 instance
    // Assuming the conversion cannot fail here, so unwrapping directly
    Array2::from_row_major(rgb_array.width(), rgb_array.height(), converted).unwrap()
}

fn main() {
    // Create a 2x2 Array2 of RGB values
    let rgb_values = vec![
        (255u8, 0, 0), // Red
        (0, 255, 0),   // Green
        (0, 0, 255),   // Blue
        (255, 255, 0), // Yellow
    ];

    let rgb_array = Array2::from_row_major(2, 2, rgb_values).unwrap();

    // Convert to floating-point representation
    let float_array = convert_rgb_to_f32(rgb_array.clone());

    // Print out the original RGB array
    println!("Original RGB Array:");
    for r in 0..rgb_array.height() {
        for c in 0..rgb_array.width() {
            if let Some(&(r, g, b)) = rgb_array.get(c, r) {
                print!("({:3}, {:3}, {:3}) ", r, g, b);
            }
        }
        println!(); // Newline after each row
    }

    // Print out the converted floating-point array
    println!("\nConverted to Floating-Point Representation:");
    for r in 0..float_array.height() {
        for c in 0..float_array.width() {
            if let Some(&(r, g, b)) = float_array.get(c, r) {
                print!("({:.2}, {:.2}, {:.2}) ", r, g, b);
            }
        }
        println!(); // Newline after each row
    }
}


// fn main() {
//     // Create an Array2 instance with odd dimensions and fill it with a specific value
//     let width = 5;
//     let height = 7;
//     let mut values = Vec::with_capacity(width * height);

//     // Fill the Vec with distinct values in row-major order
//     for i in 0..(width * height) {
//         values.push(i + 1); // Start values from 1 for easier reading
//     }

//     // Create an Array2 instance from the values vector
//     let array = Array2::from_row_major(width, height, values)
//         .expect("Failed to create Array2 from values");

//     // Print the original array
//     println!("Original Array2 ({}x{}):", array.width(), array.height());
//     for row in 0..array.height() {
//         for col in 0..array.width() {
//             print!("{} ", array.get(col, row).unwrap());
//         }
//         println!(); // Newline after each row
//     }

//     // Use the trim_to_even function to trim the array
//     let trimmed_array = array.trim_to_even();

//     // Print the trimmed array
//     println!("\nTrimmed Array2 ({}x{}):", trimmed_array.width(), trimmed_array.height());
//     for row in 0..trimmed_array.height() {
//         for col in 0..trimmed_array.width() {
//             print!("{} ", trimmed_array.get(col, row).unwrap());
//         }
//         println!(); // Newline after each row
//     }
// }