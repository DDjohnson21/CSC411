# CSC411A1

## Part C

There are various real world problems that you can solve with a functional version of fgroups. Some of these problems are below: 

**Examples**
- Duplicate files  - Using a working version of fgroups can easily help with finding duplicate files by grouping files with identical content together. From here, additional functionality could be implemented to delete duplicate files.
- Media or file organization - Can organize data based on certain qualities (keys) and sort them into the appropriate groups based on these qualities.
- Organization of data - managing data for an Airpot. The airport has airlines which correspond to different planes where each planes corresponds to different people 
